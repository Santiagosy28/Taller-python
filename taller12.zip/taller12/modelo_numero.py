class Numero:
    def __init__(self):
        self.numero = " "

    def get_numero(self):
        return self.numero
    
    def set_numero(self, nuevo_numero):
        self.numero = nuevo_numero

    def validar_par(self):
        if self.numero % 2 == 0:
            mensaje = " numero es par"
        else:
            mensaje = " numero es impar"
        return mensaje
    
    def validar_positivo(self):
        if self.numero >= 0:
            mensaje = " numero es positivo"
        else:
            mensaje = " numero es negativo"
        return mensaje
    def validar_neutro(self):
        if self.numero == 0:
            mensaje = " numero es neutro"
        else:
            mensaje = " numero no es neutro"
        return mensaje