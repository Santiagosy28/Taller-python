from modelo_numero import Numero
from vista import Vista_formulario
from controlador import Controlador
"""obj_numero = Numero()
obj_numero.set_numero(5)
print(f"el numero es : {obj_numero.get_numero()}")
print(f"el numero es : {obj_numero.validar_par()}")
print(f"el numero es : {obj_numero.validar_positivo()}")
print(f"el numero es : {obj_numero.validar_neutro()}")"""
obj_modelo= Numero()
obj_vista= Vista_formulario()
obj_controlador = Controlador(obj_vista, obj_modelo)